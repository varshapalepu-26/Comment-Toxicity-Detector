/*const API_URL = "https://938d-34-186-29-202.ngrok-free.app/predict";

const processed = new WeakSet();

function getSelector() {

  const host = location.hostname;

  if (host.includes("youtube"))
    return "#content-text";

  if (host.includes("instagram"))
    return "span";

  if (host.includes("twitter") || host.includes("x.com"))
    return "div[data-testid='tweetText']";

  if (host.includes("facebook"))
    return "div[aria-label='Comment'] span";

  if (host.includes("reddit"))
    return "p";

  return null;
}

async function analyze(element) {

  if (processed.has(element)) return;

  const text = element.innerText.trim();

  if (text.length < 3) return;

  processed.add(element);

  try {

    const response = await fetch(API_URL, {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({comment:text})
    });

    const result = await response.json();

    if (!result.is_toxic) return;

    element.style.filter = "blur(5px)";

    element.title = "Toxic comment detected";

  } catch(e) {
    console.log(e);
  }
}

function scan() {

  const selector = getSelector();

  if (!selector) return;

  const comments = document.querySelectorAll(selector);

  comments.forEach(analyze);
}

setInterval(scan,5000);
*/

const API_URL = "http://127.0.0.1:5000/predict";

const processed = new WeakSet();

function getSelector() {

  const host = location.hostname;

  if (host.includes("youtube"))
    return "#content-text";

  if (host.includes("instagram"))
    return "span";

  if (host.includes("twitter") || host.includes("x.com"))
    return "div[data-testid='tweetText']";

  if (host.includes("facebook"))
    return "div[aria-label='Comment'] span";

  if (host.includes("reddit"))
    return "p";

  return null;
}

async function analyze(element) {

  if (processed.has(element)) return;

  const text = element.innerText.trim();

  if (text.length < 3) return;

  processed.add(element);

  try {

    const response = await fetch(API_URL, {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({comment:text})
    });

    const result = await response.json();

    if (!result.is_toxic) return;

    blurComment(element);

  } catch(e) {
    console.log("API error:", e);
  }
}

function blurComment(element) {

  element.style.filter = "blur(6px)";
  element.style.cursor = "pointer";

  const warning = document.createElement("div");

  warning.innerText = "⚠️ Toxic comment — click to reveal";

  warning.style.color = "red";
  warning.style.fontSize = "12px";
  warning.style.fontWeight = "bold";
  warning.style.marginBottom = "4px";

  element.parentNode.insertBefore(warning, element);

  let blurred = true;

  element.addEventListener("click", () => {

    if (blurred) {
      element.style.filter = "none";
      warning.innerText = "⚠️ Toxic comment — click to hide";
    } else {
      element.style.filter = "blur(6px)";
      warning.innerText = "⚠️ Toxic comment — click to reveal";
    }

    blurred = !blurred;

  });

}

function scan() {

  const selector = getSelector();

  if (!selector) return;

  const comments = document.querySelectorAll(selector);

  comments.forEach(analyze);

}

setInterval(scan, 5000);