const API_URL = "http://127.0.0.1:5000/predict";

document.getElementById("check").onclick = async () => {

  const text = document.getElementById("comment").value;

  const res = await fetch(API_URL,{
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({comment:text})
  });

  const data = await res.json();

  document.getElementById("result").innerText =
    JSON.stringify(data,null,2);

};