chrome.runtime.onInstalled.addListener(() => {
  console.log("Toxicity extension installed");
});